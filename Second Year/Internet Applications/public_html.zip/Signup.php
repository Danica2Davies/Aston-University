<!DOCTYPE html>
<html>
<header>
<?php include('phpcode/register.php');?>
<script src="login.js"></script>
<div class ="test2">
  <link rel="stylesheet" href="stylesheet.css">
        <div class="container">
            <nav style="margin: -5px 0 50px;">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
					<li><a href="Signin.php">Login</a></li>
                    <li><a href="Signup.php" style="color: green;">Signup</a></li>
                </ul>
            </nav>
        </div>
		</div>
		<body>
<div class="containerLogin" id="containerLogin">
	<div class="form-container">

		<form name="CreateAccount" onsubmit="validateEmail();checkPassword();pswdvalid();" method="post">
			<h1>Create Account</h1>
			<input type="email" placeholder="Email" input type="text" name="email" required />
			<input type="password" placeholder="Password" name="password" required />
			<input type="password" name="confirm_password"  placeholder="Repeat Password"required />
			<button input type="submit" value="Submit" onClick="validateEmail();checkPassword()" > Create Account</button>
		</form>
	</div>
</header>
	</div>
</div>
</body>

<footer>
</footer>
</header>
</html>