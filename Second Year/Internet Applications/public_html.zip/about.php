<!DOCTYPE html>
<!-- basic About us page, to tell vistors a little about the website -->
<html>
<header>
  <link rel="stylesheet" href="stylesheet.css">
	<div class="test2">
            <nav style="margin: -200px 0 50px;">
                <ul>
						<!--Navigation Bar-->
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php" style="color: green;">About</a></li>
					<li><a href="Signin.php">Login</a></li>
                    <li><a href="Signup.php">Signup</a></li>
                </ul>
            </nav>
			</div>
    <!-- Basic description of Aston University Animal Sanctuary-->
  <div class="about-section">
  <h1>About Us</h1>
  <p>We Are Aston University Animal Sanctuary. Our Aim is to provide pets in need loving homes </p>
  <p> We pride ourselves on taking pets from all walks of life and uniting them with the correct owners for them </p>
</div>
</header>	
</html>
