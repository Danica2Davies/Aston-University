<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u-190141121');
define('DB_PASSWORD', 'KwCMR93lrh3eyAF');
define('DB_NAME', 'u_190141121_db');
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect them to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
$id = $_SESSION["id"];
?>
 
<!DOCTYPE html>
<html lang="en">
<header>
 <meta charset="UTF-8">
  <title>Admin</title>
<link rel="stylesheet" href="stylesheet2.css">
    <link rel="stylesheet" href="stylesheet.css">
        <div class="container">
            <nav style="margin: 50px 0 50px;">
                <ul>
							<!-- navigation -->
                    <li><a href="uploaddamnit.php">NewPet</a></li>
                    <li><a href="AdminAnimals.php">Animals</a></li>
                    <li><a href="welcomeAdmin.php" style="color: red;">Requests</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
          </div>
 <nav style="margin: -5px 0 50px;">
    <div class="containerLogin" id="containerLogin">
	<div class="form-container">
	<form name="Profile" method="post" >
        <br> 

       <h3 style = "font: 12px;">Animal Adoption Requests:</h3>
    
<table id="animalsbox" border='0'>
<tr>

<th>AccountID</th>
<th>AnimalID</th>
<th>Adoption Status</th>
</tr>


<?php
$result = mysqli_query($link,"SELECT * FROM requests WHERE status = 'Request Pending'");
while ($rsa = mysqli_fetch_array($result)) {
    echo "<tr>";

        echo "<td>" . $rsa['accountid'] . "</td>";	
        echo "<td>" . $rsa['animalid'] . "</td>";	
  		echo "<td>" . $rsa['status'] . "</td>";
}


  	echo "</tr>";
  echo "</table>";
?>
	</header>
</html>