<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u-190141121');
define('DB_PASSWORD', 'KwCMR93lrh3eyAF');
define('DB_NAME', 'u_190141121_db');
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect them to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
}
$id = $_SESSION["id"];

$sql = "SELECT * FROM requests WHERE accountid = '$id'";




// <?php
// $result = mysql_query("SELECT id,email FROM people WHERE id = '42'");
// if (!$result) {
//     echo 'Could not run query: ' . mysql_error();
//     exit;

// $row = mysql_fetch_row($result);

// echo $row[0]; // 42
// echo $row[1]; // the email value
// 
?>

<!DOCTYPE html>
<html lang="en">
<header>
<meta charset="UTF-8">
  <title>User</title>
<link rel="stylesheet" href="stylesheet2.css">
<link rel="stylesheet" href="stylesheet.css">
        <div class="container">
            <nav style="margin: 10px 0 50px;">
                <ul>
						<!-- Navigation -->
                    <li><a href="Animals.php">Animals</a></li>
                    <li><a href="welcome.php" style="color: red;">Profile</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
    <nav style="margin: -5px 0 50px;">
    <div class="containerLogin" id="containerLogin">
	<div class="form-container">
	<form name="Profile" method="post" >
   <h1 style="color: white; font: 30px sans-serif; text-align: center; margin: -10px 0 50px">Hi, <b><?php echo $email ?></b>. Welcome back Administrator!.</h1>
        <br> 

       <h3 style = "font: 12px;">Animal Adoption Requests:</h3>
    
<table id="animalsbox" border='0'>
<tr>
<th>AnimalID</th>
<th>Adoption Status</th>
</tr>
<?php
$result = mysqli_query($link,"SELECT * FROM requests WHERE accountid = '$id'");
while ($rsa = mysqli_fetch_array($result)) {
    echo "<tr>";
//while($rsa = mysqli_fetch_array($result)) {
        echo "<td>" . $rsa['animalid'] . "</td>";	
  		echo "<td>" . $rsa['status'] . "</td>";
}


  	echo "</tr>";
  echo "</table>";
?>


			<b href="#">Lots of Animals still need adoption!</b>
<br>
		</form>
	</div>
                        
</header>

</html>
