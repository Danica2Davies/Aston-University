<?php
// Initialize the session
session_start();
 
/* Database credentials */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u-190141121');
define('DB_PASSWORD', 'KwCMR93lrh3eyAF');
define('DB_NAME', 'u_190141121_db');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);


// Define variables
$email = $password = "";
$email_err = $password_err = $login_err = "";


 
// Process form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if email is empty
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter email.";
    } else{
        $email = trim($_POST["email"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($email_err) && empty($password_err)){
        //select the relevent fields and confirm that they are Users not Admins (Admin = 0 means a user)
        $sql = "SELECT id, email, password FROM users WHERE email = ? && Admin = 0";
    	//prepare the sql
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email); // s' specifies the variable type => 'string' to try prevent people from entering sql injections by informing the system that this is a string
            
            // Set parameters
            $param_email = $email;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if email exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $email, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                                if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: phpcode/welcome.php");
    exit;
    }
                            session_start();
                            
                            // Create session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email; 
                            
                            // Redirect user to welcome page
                            header("location: phpcode/welcome.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid email or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid email or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

        if(empty($email_err) && empty($password_err)){
        // prepare a select statement for if an Admin is trying to login by varifying the (Admin=1) prompt
            $sql2 = "SELECT id, email, password FROM users WHERE email = ? && Admin = 1";
        	//prepare the sql2
              if($stmt = mysqli_prepare($link, $sql2)){
            // Bind variables to the prepared statement as parameters, declaring them a string
            mysqli_stmt_bind_param($stmt, "s", $param_email);
 
            // Set parameters
            $param_email = $email;
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if email exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $email, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: phpcode/welcomeAdmin.php");
    exit;
    }
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["email"] = $email; 
                            
                            // Redirect user to Admins page
                            header("location: phpcode/welcomeAdmin.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid email or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid email or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
}
    // Close connection
    mysqli_close($link);

?>