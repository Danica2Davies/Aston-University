<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u-190141121');
define('DB_PASSWORD', 'KwCMR93lrh3eyAF');
define('DB_NAME', 'u_190141121_db');
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($_SERVER["REQUEST_METHOD"] == "POST"){
//if(isset($_POST['but_upload'])){
  $animalname = $_POST['animalname'];
  $date = $_POST['date'];
  $description = $_POST['description'];
  $avalibility = $_POST['avalibility'];
    
  $name = $_FILES['file']['name'];
  $target_dir = "upload/";
  $target_file = $target_dir . basename($_FILES["file"]["name"]);

  // Select file type
  $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

  // Valid file extensions
  $extensions_arr = array("jpg","jpeg","png","gif");

  // Check extension
  if( in_array($imageFileType,$extensions_arr) ){

     // Insert record
     $query = "INSERT INTO test(date,avalibility,description,animalname,name) VALUES('$date','$avalibility','$description','$animalname','".$name."')";
     mysqli_query($link,$query);
  
     // Upload file
     move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$name);
  	echo 'Pet Uploaded';

  }
  
$sql = "select name from test where Animalid=13";
$result = mysqli_query($link,$sql);
$row = mysqli_fetch_array($result);

$image = $row['name'];
$image_src = "upload/".$image;
 
}
?>

<!DOCTYPE html>
<html>
<header>
        <div class="container">
            <nav style="margin: -5px 0 50px;">
                <ul>
							<!--Navigation -->
                     <li><a href="uploaddamnit.php" style="color: red;">New Pet</a></li>
                    <li><a href="AdminAnimals.php">Animals</a></li>
                    <li><a href="welcomeAdmin.php">Requests</a></li>
                    <li><a href="logout.php">Log Out</a></li>                   
                </ul>
            </nav>
        </div>
    <link rel="stylesheet" href="stylesheet.css">
<div class="containerLogin" id="containerLogin">
	<div class="form-container">

<form method="post" action="" enctype='multipart/form-data'>
    <input type="animalname" placeholder="Name" input type="text" name="animalname" required />
        <input type="date" placeholder="Date" input type="date" name="date" required />
            <input type="description" placeholder="Description" input type="text" name="description" required />
                <input type="avalibility" placeholder="avalibility" input type="text" name="avalibility" required />
  <input type='file' name='file' />
  <input type='submit' value='Upload' name='but_upload'>
    </form> </div> </div>



</header>
</html>