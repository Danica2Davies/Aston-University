<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u-190141121');
define('DB_PASSWORD', 'KwCMR93lrh3eyAF');
define('DB_NAME', 'u_190141121_db');
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
?>