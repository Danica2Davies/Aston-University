<?php
// Initialize the session
session_start();

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u-190141121');
define('DB_PASSWORD', 'KwCMR93lrh3eyAF');
define('DB_NAME', 'u_190141121_db');
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check if the user is logged in, if not then redirect them
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ../login.php");
    exit;
}

?>
 

<!DOCTYPE html>
<html lang="en">
<header width="300px">
    <meta charset="UTF-8">
    <title>Welcome</title>
        <?php include('connect.php');?>
    <link rel="stylesheet" href="stylesheet.css">
<link rel="stylesheet" href="stylesheet2.css">
        <div class="container">
            <nav style="margin: 50px 0 50px;">
                <ul>
							<!--Navigation -->
                    <li><a href="Animals.php" style="color: red;">Animals</a></li>
                    <li><a href="welcome.php">Profile</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
</header>
<br>
    
				<!-- slideshow -->
<h2 style="text-align:center"><?php echo "Table of Animals" ?></h2>
	<div class="slideshow-container">
  		<div class="mySlides1">

    
    
<br> <p>
<br>
<br> <p>
<br> <br>

<!-- Animal Table -->
<table id="animalsbox" border='0'>
<tr>
<th>AnimalID</th>
<th>Name</th>
<th>Date</th>
<th>Description</th>
<th>Avalibility</th>
<th>Photos</th>
<th>Adopt</th>

</tr>



<?php
$result = mysqli_query($link,"SELECT * FROM test");
while($row = mysqli_fetch_array($result))
{

	echo "<tr>";
?>
<?php $animal = $row['Animalid']; 
$sql6 = "select name from test where Animalid = $animal";
$results = mysqli_query($link,$sql6);
$rows = mysqli_fetch_array($results);
$image = $rows['name'];
$image_src = "upload/".$image;

?>
	<td> <?php echo $row['Animalid']; ?> </td>
	<td> <?php echo $row['animalname']; ?> </td>
	<td> <?php echo $row['date']; ?> </td> 
	<td> <?php echo $row['description']; ?> </td> 
	<td> <?php echo $row['avalibility']; ?> </td> 
<td>
<img width="70" height="60" src='<?php echo  $image_src;?>' > </td>  
<form action="" method="post">
<td> <button style="color:green;" input type="submit" value="Submit" name="<?php echo $animal ?>" > Adopt Today</button> </td> </form>

		<?php 
if(isset($_POST[$animal])) {
$id = $_SESSION["id"];
$sql55 = "INSERT INTO requests (status,animalid,accountid) VALUES ('Request Pending','$animal','$id')";
if(mysqli_query($link, $sql55)){
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}

	echo "</tr>";

}

echo "</table>";
?>

<br><br>
    <script>
var slideIndex = [1,1];
var slideId = ["mySlides1", "mySlides2"]
showSlides(1, 0);
showSlides(1, 1);

function plusSlides(n, no) {
  showSlides(slideIndex[no] += n, no);
}

function showSlides(n, no) {
  var i;
  var x = document.getElementsByClassName(slideId[no]);
  if (n > x.length) {slideIndex[no] = 1}    
  if (n < 1) {slideIndex[no] = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex[no]-1].style.display = "block";  
}
</script>
    
</html>