<!DOCTYPE html>
<html>
<header>
  <link rel="stylesheet" href="stylesheet.css">
	<div class="test2">
            <nav style="margin: -285px 0 50px;">
                <ul>
						<!-- Navigation Bar -->
                    <li><a href="index.php" style="color: green;">Home</a></li>
                    <li><a href="about.php">About</a></li>
					<li><a href="Signin.php">Login</a></li>
                    <li><a href="Signup.php">Signup</a></li>
                </ul>
            </nav>
			</div>
	</header>
<body>
<br>
<!-- Dogs -->
  <div class="column">
    <div class="card">
  <img src="dogo.jpg" alt="Dogs" style="width:100%">
  <h1>Dogs</h1><br>
    </div>
  </div>

<!-- Cats -->
  <div class="column">
    <div class="card">
  <img src="catphoto.jpg" alt="Cats" style="width:100%">
  <h1>Cats</h1><br>
    </div>
  </div>
  
<!-- Rabbits -->
  <div class="column">
  <div class="card">
  <img src="jacky.png" alt="Rabbits" style="width:100%">
  <h1>Rabbits</h1> <br>
  </div>
  </div>
 
<!-- More -->
  <div class="column">
  <div class="card">
  <img src="rep.jpg" alt="More Animals" style="width:90%">
  <h1>And More</h1><br>
    </div>
  </div>

</div>
</body>
</html>
