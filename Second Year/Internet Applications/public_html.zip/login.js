
      alert("test");
function validateEmail() {
  var x = document.forms["myForm"]["mail"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
  
    function checkPassword() {
    password1 = form.pswd.value;
    password2 = form.pswd2.value;
    if (password1 != password2) {
                 alert ("\nPassword did not match: Please try again...");
                    return false;
                }
      alert("test");
	}

