<!DOCTYPE html>
<html>
<header>
<?php include('phpcode/login.php');?>
<div class ="test2">
  <link rel="stylesheet" href="stylesheet.css">
        <div class="container">
            <nav style="margin: -5px 0 50px;">
                <ul>
						<!-- Navigation bar -->
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
					<li><a href="Signin.php" style="color: green;">Login</a></li>
                    <li><a href="Signup.php">Signup</a></li>
                </ul>
            </nav>
        </div>
		</div>
		<body>
<!-- Sign In Form -->
<div class="containerLogin" id="containerLogin">
	<div class="form-container">
	<form name="Account" method="post" >
			<h1>Sign in</h1>
			<input type="email" placeholder="Email" name="email" />
			<input type="password" placeholder="Password" name="password" />
			<b href="#">Forgot your password?</b>
			<button style="color:red;"input type="submit" value="Submit"> Signin</button>
		</form>
	</div>
	</div>
        </header>
</body>
</header>
</html>